import { THREE_TYPE } from "./Definitions.js";
/**
 * @module Three.js
 */
export declare const THREE: typeof THREE_TYPE;
/**
 * @module Howler.js
 */
declare const Howl: any;
export { Howl };
